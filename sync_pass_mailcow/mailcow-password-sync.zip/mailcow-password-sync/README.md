# Techfarm - Keycloak → Mailcow password sync

Plugin này ghi đè Required Action `UPDATE_PASSWORD` mặc định của Keycloak.

Khi user đổi password tại:

```text
https://login.techfarm.com.vn/realms/techfarm/account/
```

luồng sẽ là:

```text
User đổi password
      |
      v
Keycloak UPDATE_PASSWORD
      |
      +--> Keycloak lưu password bình thường
      |
      +--> plugin xác minh password mới đã được Keycloak chấp nhận
                |
                v
        bcrypt(password mới)
                |
                v
mailcow_password = {BLF-CRYPT}$2a$...
                |
                v
Mailcow Mailpassword Flow
IMAP / SMTP / POP3 / SIEVE
```

## Phạm vi

Mặc định plugin chỉ chạy cho realm:

```text
techfarm
```

và chỉ sync user có attribute:

```text
mailcow_template
```

Nhờ vậy realm `master` và user không dùng Mailcow không bị thêm `mailcow_password`.

---


## Build script tự cài dependency

`build.sh` hiện đã tự kiểm tra và cài các dependency cần thiết trên Ubuntu/Debian:

- `ca-certificates`
- `curl`
- OpenJDK 21 nếu Java chưa có hoặc thấp hơn 21
- Maven nếu chưa có

Chỉ cần:

```bash
cd /opt/mailcow-password-sync
chmod +x build.sh
./build.sh
```

Script chỉ build plugin; chưa tự deploy/restart Keycloak để tránh vô tình làm gián đoạn dịch vụ. Sau khi build xong nó sẽ in sẵn các lệnh deploy.

---

## 1. Kiểm tra phiên bản Keycloak

Trên server:

```bash
/opt/keycloak/bin/kc.sh --version
```

`pom.xml` đang mặc định:

```xml
<keycloak.version>26.7.4</keycloak.version>
```

Nên dùng đúng version Keycloak đang chạy.

Ví dụ server chạy `26.6.4`:

```bash
mvn -Dkeycloak.version=26.6.4 clean package
```

Hoặc sửa trực tiếp `pom.xml`.

> Plugin dùng API nội bộ `keycloak-services`, vì vậy nên build đúng version server.

---

## 2. Cài Maven nếu chưa có

Ubuntu/Debian:

```bash
apt update
apt install -y maven
```

Kiểm tra:

```bash
mvn -version
java -version
```

Keycloak 26.x nên chạy Java 21.

---

## 3. Build

Trong thư mục project:

```bash
mvn clean package
```

Sau khi build thành công:

```text
target/mailcow-password-sync-1.0.0.jar
```

JAR đã shade `jbcrypt`, không cần copy dependency BCrypt riêng.

---

## 4. Cài plugin vào Keycloak

Backup trước:

```bash
mkdir -p /root/keycloak-provider-backup
cp -a /opt/keycloak/providers /root/keycloak-provider-backup/providers-$(date +%F-%H%M%S)
```

Copy plugin:

```bash
cp target/mailcow-password-sync-1.0.0.jar /opt/keycloak/providers/
```

Build lại Keycloak:

```bash
cd /opt/keycloak
bin/kc.sh build
```

Restart service:

```bash
systemctl restart keycloak
systemctl status keycloak --no-pager
```

Theo dõi log:

```bash
journalctl -u keycloak -f
```

---

## 5. Biến môi trường tùy chọn

### Realm cần sync

Mặc định:

```text
MAILCOW_SYNC_REALM=techfarm
```

Nếu systemd, có thể thêm vào service override:

```bash
systemctl edit keycloak
```

Thêm:

```ini
[Service]
Environment="MAILCOW_SYNC_REALM=techfarm"
Environment="MAILCOW_BCRYPT_COST=12"
Environment="MAILCOW_SYNC_REQUIRE_TEMPLATE=true"
```

Sau đó:

```bash
systemctl daemon-reload
systemctl restart keycloak
```

### Ý nghĩa

```text
MAILCOW_SYNC_REALM
```

Realm được phép tạo `mailcow_password`.

```text
MAILCOW_BCRYPT_COST
```

Cost bcrypt, mặc định `12`, giới hạn plugin `4..16`.

```text
MAILCOW_SYNC_REQUIRE_TEMPLATE
```

Mặc định `true`.

Nếu `true`, chỉ user có:

```text
mailcow_template
```

mới được đồng bộ password sang Mailcow.

---

## 6. Keycloak User Profile

Bạn đã tạo:

```text
mailcow_template
mailcow_password
```

Khuyến nghị permission của `mailcow_password`:

```text
Admin: View + Edit
User:  không cho View/Edit
```

User không cần nhìn thấy hash.

Plugin ghi attribute trực tiếp ở backend.

---

## 7. Mailcow

Mailcow cần:

```text
Identity Provider: Keycloak
Mailpassword Flow: ON
```

Keycloak client `mailcow` cần:

```text
Service account roles: ON
realm-management → view-users
```

Mailcow sẽ gọi Keycloak Admin REST API và đọc:

```text
mailcow_password
```

Không cần OIDC mapper cho `mailcow_password`.

---

## 8. Test

### Bước A - xem hash cũ

Trong Keycloak Admin:

```text
Users
→ user@example.com
→ Details
→ Mailcow Password
```

Ghi nhận hash hiện tại, ví dụ chỉ cần nhìn vài ký tự đầu/cuối; không copy ra log công khai.

### Bước B - đổi password

User vào:

```text
https://login.techfarm.com.vn/realms/techfarm/account/
```

đổi password.

### Bước C - xem log

```bash
journalctl -u keycloak -n 100 --no-pager | grep -i mailcow
```

Nếu thành công sẽ có dòng tương tự:

```text
Mailcow password hash synchronized for user 'user@example.com' in realm 'techfarm'
```

Plugin KHÔNG log plaintext password và KHÔNG log password hash.

### Bước D - kiểm tra attribute

Reload user trên Admin Console.

`mailcow_password` phải đổi thành hash mới:

```text
{BLF-CRYPT}$2a$...
```

### Bước E - test IMAP/SMTP

Dùng chính password mới vừa đặt ở Keycloak để đăng nhập client IMAP/SMTP.

---

## 9. Điều quan trọng

Plugin này đồng bộ khi user đi qua Required Action:

```text
UPDATE_PASSWORD
```

Nó bao gồm luồng đổi password từ Account Console của Keycloak.

Đây KHÔNG phải hook cho mọi cách có thể cập nhật credential trong Keycloak.

Ví dụ admin thay password trực tiếp bằng Admin REST API/Admin Console có thể đi qua luồng credential API khác và không có plaintext password trong Required Action này.

Nếu muốn mô hình luôn đồng bộ, nên quy định:

```text
User đổi password:
→ Account Console

Admin cần reset:
→ đặt Temporary Password / Execute Actions
→ bắt user thực hiện UPDATE_PASSWORD
```

Khi user tự nhập password mới qua `UPDATE_PASSWORD`, plugin mới có plaintext cần thiết để tạo hash Mailcow.

---

## 10. Rollback

Nếu có vấn đề:

```bash
rm -f /opt/keycloak/providers/mailcow-password-sync-1.0.0.jar

cd /opt/keycloak
bin/kc.sh build

systemctl restart keycloak
```

Sau đó Keycloak quay về implementation `UPDATE_PASSWORD` built-in.

---

## 11. Bảo mật

`mailcow_password` là một password verifier. Dù là hash chứ không phải plaintext, vẫn cần bảo vệ như dữ liệu credential:

- Không cho user đọc attribute này.
- Không đưa vào OIDC token/UserInfo.
- Không tạo mapper cho `mailcow_password`.
- Chỉ cấp `view-users` cho đúng service account Mailcow cần dùng.
- Không log attribute/hash.
- Hạn chế quyền Admin Console/Keycloak Admin API.
- Backup Keycloak DB phải được bảo vệ.

---

## 12. Cấu trúc project

```text
mailcow-password-sync/
├── pom.xml
├── README.md
└── src/
    └── main/
        ├── java/
        │   └── vn/
        │       └── techfarm/
        │           └── keycloak/
        │               └── mailcow/
        │                   └── MailcowSyncUpdatePassword.java
        └── resources/
            └── META-INF/
                └── services/
                    └── org.keycloak.authentication.RequiredActionFactory
```
