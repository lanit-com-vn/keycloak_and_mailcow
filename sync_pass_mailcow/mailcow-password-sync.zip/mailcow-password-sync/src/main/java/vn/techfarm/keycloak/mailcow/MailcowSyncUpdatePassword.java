package vn.techfarm.keycloak.mailcow;

import java.util.Objects;

import jakarta.ws.rs.core.MultivaluedMap;

import org.jboss.logging.Logger;
import org.keycloak.authentication.RequiredActionContext;
import org.keycloak.authentication.RequiredActionProvider;
import org.keycloak.authentication.requiredactions.UpdatePassword;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.UserModel;
import org.mindrot.jbcrypt.BCrypt;

/**
 * Ghi đè Required Action UPDATE_PASSWORD mặc định của Keycloak.
 *
 * Keycloak vẫn xử lý đổi mật khẩu bằng implementation gốc.
 * Sau khi mật khẩu mới thực sự hợp lệ trong Keycloak, provider này tạo
 * bcrypt hash và cập nhật:
 *
 *     mailcow_password = {BLF-CRYPT}$2a$...
 *
 * Mailcow Mailpassword Flow sau đó đọc attribute này qua Keycloak Admin REST API.
 *
 * Không ghi plaintext password hoặc hash vào log.
 */
public final class MailcowSyncUpdatePassword extends UpdatePassword {

    private static final Logger LOG = Logger.getLogger(MailcowSyncUpdatePassword.class);

    private static final String MAILCOW_PASSWORD_ATTRIBUTE = "mailcow_password";
    private static final String MAILCOW_TEMPLATE_ATTRIBUTE = "mailcow_template";

    /**
     * Chỉ sync realm này. Có thể override bằng biến môi trường MAILCOW_SYNC_REALM.
     */
    private static final String TARGET_REALM =
            env("MAILCOW_SYNC_REALM", "techfarm");

    /**
     * Bcrypt cost. 12 là mức mặc định của plugin.
     * Có thể override bằng MAILCOW_BCRYPT_COST, giới hạn 4..16.
     */
    private static final int BCRYPT_COST =
            intEnv("MAILCOW_BCRYPT_COST", 12, 4, 16);

    /**
     * Nếu true, chỉ sync user có mailcow_template.
     * Mặc định true để tránh tạo mailcow_password cho user không dùng Mailcow.
     */
    private static final boolean REQUIRE_MAILCOW_TEMPLATE =
            boolEnv("MAILCOW_SYNC_REQUIRE_TEMPLATE", true);

    @Override
    public void processAction(RequiredActionContext context) {
        MultivaluedMap<String, String> formData =
                context.getHttpRequest().getDecodedFormParameters();

        String passwordNew = formData.getFirst("password-new");
        String passwordConfirm = formData.getFirst("password-confirm");

        /*
         * Cho Keycloak xử lý toàn bộ logic gốc:
         * - password policy
         * - confirm password
         * - credential update
         * - logout other sessions
         * - event/error handling
         */
        super.processAction(context);

        /*
         * Chỉ sync nếu Required Action gốc thực sự thành công.
         * Nếu password policy bị reject hoặc Keycloak trả challenge/error,
         * context sẽ không ở trạng thái SUCCESS.
         */
        if (context.getStatus() != RequiredActionContext.Status.SUCCESS) {
            return;
        }

        if (passwordNew == null
                || passwordNew.isBlank()
                || !Objects.equals(passwordNew, passwordConfirm)) {
            return;
        }

        String realmName = context.getRealm().getName();
        if (!TARGET_REALM.equals(realmName)) {
            LOG.debugf(
                    "Mailcow sync skipped: realm '%s' is not target realm '%s'",
                    realmName, TARGET_REALM);
            return;
        }

        UserModel user = context.getUser();

        if (REQUIRE_MAILCOW_TEMPLATE) {
            String template = user.getFirstAttribute(MAILCOW_TEMPLATE_ATTRIBUTE);
            if (template == null || template.isBlank()) {
                LOG.debugf(
                        "Mailcow sync skipped for user '%s': no %s attribute",
                        safeUsername(user), MAILCOW_TEMPLATE_ATTRIBUTE);
                return;
            }
        }

        try {
            /*
             * jBCrypt tạo $2a$..., đây vẫn là bcrypt/BLF-CRYPT.
             * Mailcow verify_hash() chuyển phần sau {BLF-CRYPT} cho
             * password_verify(), hỗ trợ bcrypt.
             */
            String bcrypt = BCrypt.hashpw(passwordNew, BCrypt.gensalt(BCRYPT_COST));
            String mailcowHash = "{BLF-CRYPT}" + bcrypt;

            user.setSingleAttribute(MAILCOW_PASSWORD_ATTRIBUTE, mailcowHash);

            LOG.infof(
                    "Mailcow password hash synchronized for user '%s' in realm '%s'",
                    safeUsername(user), realmName);
        } catch (Exception e) {
            /*
             * Không log password/hash.
             *
             * Ném exception để request fail thay vì im lặng báo thành công
             * trong khi Mailcow chưa được cập nhật. Với user local Keycloak,
             * thay đổi password và attribute nằm trong cùng transaction.
             */
            LOG.errorf(
                    e,
                    "Mailcow password sync FAILED for user '%s' in realm '%s'",
                    safeUsername(user), realmName);

            throw new IllegalStateException(
                    "Keycloak password changed but mailcow_password synchronization failed",
                    e);
        }
    }

    /**
     * Phải trả về chính custom provider, nếu không create() kế thừa từ
     * UpdatePassword sẽ tạo instance built-in và processAction custom không chạy.
     */
    @Override
    public RequiredActionProvider create(KeycloakSession session) {
        return new MailcowSyncUpdatePassword();
    }

    /**
     * Giữ nguyên provider ID UPDATE_PASSWORD do kế thừa getId() từ UpdatePassword.
     * order cao hơn built-in để Keycloak chọn implementation này.
     */
    @Override
    public int order() {
        return 100;
    }

    @Override
    public String getDisplayText() {
        return "Update Password + Mailcow Sync";
    }

    private static String safeUsername(UserModel user) {
        String username = user == null ? null : user.getUsername();
        return username == null ? "<unknown>" : username;
    }

    private static String env(String name, String defaultValue) {
        String value = System.getenv(name);
        return value == null || value.isBlank() ? defaultValue : value.trim();
    }

    private static int intEnv(String name, int defaultValue, int min, int max) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        try {
            int parsed = Integer.parseInt(value.trim());
            return Math.max(min, Math.min(max, parsed));
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static boolean boolEnv(String name, boolean defaultValue) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) {
            return defaultValue;
        }
        return switch (value.trim().toLowerCase()) {
            case "1", "true", "yes", "y", "on" -> true;
            case "0", "false", "no", "n", "off" -> false;
            default -> defaultValue;
        };
    }
}
