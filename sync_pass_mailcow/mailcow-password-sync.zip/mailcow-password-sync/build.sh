#!/usr/bin/env bash
set -euo pipefail

# ============================================================
# Techfarm - Keycloak -> Mailcow Password Sync
# Self-contained build script for Ubuntu/Debian
#
# Script này sẽ:
#   1. Kiểm tra quyền root/sudo
#   2. Tự cài Java 21 nếu thiếu / version quá thấp
#   3. Tự cài Maven nếu thiếu
#   4. Tự phát hiện version Keycloak
#   5. Build plugin đúng version Keycloak đang chạy
#
# Mặc định KHÔNG tự copy JAR vào Keycloak và KHÔNG restart service.
# Sau khi build xong sẽ in lệnh deploy để bạn chạy.
# ============================================================

KEYCLOAK_HOME="${KEYCLOAK_HOME:-/opt/keycloak}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JAR_NAME="mailcow-password-sync-1.0.0.jar"

log() {
  printf '\n\033[1;34m[INFO]\033[0m %s\n' "$*"
}

warn() {
  printf '\n\033[1;33m[WARN]\033[0m %s\n' "$*"
}

die() {
  printf '\n\033[1;31m[ERROR]\033[0m %s\n' "$*" >&2
  exit 1
}

# ------------------------------------------------------------
# 1. Xác định quyền cài package
# ------------------------------------------------------------
if [[ "$(id -u)" -eq 0 ]]; then
  SUDO=""
elif command -v sudo >/dev/null 2>&1; then
  SUDO="sudo"
else
  die "Cần chạy bằng root hoặc user có sudo."
fi

# ------------------------------------------------------------
# 2. Kiểm tra hệ điều hành/package manager
# ------------------------------------------------------------
if ! command -v apt-get >/dev/null 2>&1; then
  die "Script hiện hỗ trợ Ubuntu/Debian (apt-get)."
fi

export DEBIAN_FRONTEND=noninteractive

APT_UPDATED=0

apt_update_once() {
  if [[ "$APT_UPDATED" -eq 0 ]]; then
    log "apt-get update ..."
    $SUDO apt-get update
    APT_UPDATED=1
  fi
}

install_packages() {
  apt_update_once
  log "Cài package: $*"
  $SUDO apt-get install -y --no-install-recommends "$@"
}

# ------------------------------------------------------------
# 3. Các package cơ bản
# ------------------------------------------------------------
MISSING_BASE=()

command -v curl >/dev/null 2>&1 || MISSING_BASE+=("curl")
dpkg -s ca-certificates >/dev/null 2>&1 || MISSING_BASE+=("ca-certificates")

if (( ${#MISSING_BASE[@]} > 0 )); then
  install_packages "${MISSING_BASE[@]}"
fi

# ------------------------------------------------------------
# 4. Java
# ------------------------------------------------------------
get_java_major() {
  local version
  version="$(
    java -version 2>&1 \
      | awk -F '"' '/version/ {print $2; exit}'
  )"

  if [[ -z "$version" ]]; then
    echo 0
    return
  fi

  # Java 8 -> 1.8.x, Java 17/21 -> 17.x / 21.x
  if [[ "$version" == 1.* ]]; then
    echo "$version" | cut -d. -f2
  else
    echo "$version" | cut -d. -f1
  fi
}

JAVA_MAJOR=0
if command -v java >/dev/null 2>&1; then
  JAVA_MAJOR="$(get_java_major)"
fi

if [[ "$JAVA_MAJOR" -lt 21 ]]; then
  if [[ "$JAVA_MAJOR" -eq 0 ]]; then
    warn "Chưa có Java. Cài OpenJDK 21..."
  else
    warn "Java hiện tại là Java $JAVA_MAJOR. Plugin cần JDK 21 để build."
  fi

  install_packages openjdk-21-jdk-headless

  # Ưu tiên Java 21 nếu máy có nhiều Java.
  if command -v update-alternatives >/dev/null 2>&1; then
    JAVA21_BIN="$(find /usr/lib/jvm -type f -path '*/bin/java' 2>/dev/null \
      | grep -E 'java-21|jdk-21' | head -n1 || true)"

    JAVAC21_BIN="$(find /usr/lib/jvm -type f -path '*/bin/javac' 2>/dev/null \
      | grep -E 'java-21|jdk-21' | head -n1 || true)"

    if [[ -n "$JAVA21_BIN" ]]; then
      $SUDO update-alternatives --set java "$JAVA21_BIN" 2>/dev/null || true
    fi

    if [[ -n "$JAVAC21_BIN" ]]; then
      $SUDO update-alternatives --set javac "$JAVAC21_BIN" 2>/dev/null || true
    fi
  fi
fi

command -v java >/dev/null 2>&1 || die "Không tìm thấy Java sau khi cài."
command -v javac >/dev/null 2>&1 || die "Không tìm thấy javac sau khi cài."

JAVA_MAJOR="$(get_java_major)"

if [[ "$JAVA_MAJOR" -lt 21 ]]; then
  die "Java đang active là Java $JAVA_MAJOR. Cần Java 21+ để build."
fi

log "Java:"
java -version

# ------------------------------------------------------------
# 5. Maven
# ------------------------------------------------------------
if ! command -v mvn >/dev/null 2>&1; then
  warn "Chưa có Maven. Đang tự cài..."
  install_packages maven
fi

command -v mvn >/dev/null 2>&1 || die "Không tìm thấy Maven sau khi cài."

log "Maven:"
mvn -version

# ------------------------------------------------------------
# 6. Kiểm tra Keycloak
# ------------------------------------------------------------
if [[ ! -x "$KEYCLOAK_HOME/bin/kc.sh" ]]; then
  die "Không tìm thấy $KEYCLOAK_HOME/bin/kc.sh. Nếu Keycloak ở chỗ khác, chạy:
KEYCLOAK_HOME=/duong/dan/keycloak ./build.sh"
fi

RAW_VERSION="$("$KEYCLOAK_HOME/bin/kc.sh" --version 2>/dev/null || true)"
KC_VERSION="$(
  printf '%s\n' "$RAW_VERSION" \
    | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' \
    | head -n1 || true
)"

if [[ -z "$KC_VERSION" ]]; then
  die "Không tự xác định được version Keycloak từ: $KEYCLOAK_HOME/bin/kc.sh --version"
fi

log "Keycloak detected: $KC_VERSION"

# ------------------------------------------------------------
# 7. Build plugin
# ------------------------------------------------------------
cd "$PROJECT_DIR"

log "Build plugin với Keycloak $KC_VERSION ..."
mvn \
  -Dkeycloak.version="$KC_VERSION" \
  -DskipTests \
  clean package

JAR_PATH="$PROJECT_DIR/target/$JAR_NAME"

if [[ ! -f "$JAR_PATH" ]]; then
  die "Build xong nhưng không tìm thấy $JAR_PATH"
fi

log "BUILD THÀNH CÔNG"
ls -lh "$JAR_PATH"

cat <<EOF

============================================================
JAR:
  $JAR_PATH

BƯỚC DEPLOY:
  cp "$JAR_PATH" "$KEYCLOAK_HOME/providers/"

  cd "$KEYCLOAK_HOME"
  bin/kc.sh build

  systemctl restart keycloak
  systemctl status keycloak --no-pager

THEO DÕI LOG:
  journalctl -u keycloak -f

Realm mặc định plugin:
  techfarm

Có thể đổi lúc Keycloak chạy bằng systemd:
  systemctl edit keycloak

Thêm:
  [Service]
  Environment="MAILCOW_SYNC_REALM=techfarm"
  Environment="MAILCOW_BCRYPT_COST=12"
  Environment="MAILCOW_SYNC_REQUIRE_TEMPLATE=true"

Sau đó:
  systemctl daemon-reload
  systemctl restart keycloak
============================================================

EOF
